@echo off
REM RooMNRooF CAD PRO ULTIMATE - LISP Edition installer (per user, no admin, no registry).
setlocal
set SRC=%~dp0RooMNRooF.bundle
set DST=%APPDATA%\Autodesk\ApplicationPlugins\RooMNRooF.bundle
echo RooMNRooF CAD PRO ULTIMATE - LISP Edition 2.0.0
echo.
echo This is a DRAFTING tool. It does not design structures or verify code compliance.
echo All design values are project inputs to be checked by the responsible engineer.
echo.
if not exist "%SRC%\PackageContents.xml" ( echo ERROR: run Install.bat from the extracted zip folder. & pause & exit /b 1 )
tasklist /FI "IMAGENAME eq acad.exe" | find /I "acad.exe" >nul && ( echo Please close AutoCAD first, then run Install.bat again. & pause & exit /b 1 )
if exist "%DST%" (
  choice /M "An existing RooMNRooF.bundle was found. Replace it"
  if errorlevel 2 ( echo Cancelled. & pause & exit /b 1 )
  rmdir /S /Q "%DST%"
)
xcopy "%SRC%" "%DST%\" /E /I /Y /Q >nul || ( echo Copy failed. & pause & exit /b 1 )
echo.
echo Installed to: %DST%
echo Start AutoCAD. If a security prompt appears for RNR_Load.lsp choose "Always Load".
echo Then type RNRL-SELFTEST to verify, and RNRL-HELP for the command list.
pause
