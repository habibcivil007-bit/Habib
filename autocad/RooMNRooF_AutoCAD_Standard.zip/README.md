# RooMNRooF PRO 2D AutoCAD Standard — 7.0 COORDINATION SUITE

`RooMNRooF_Master.lsp` is a professional, metric AutoLISP generator for a modern
consultant 2D CAD standard. It creates a consistent visual system rather than only a
list of layers: brand colours, lineweight hierarchy, modern font fallback, rich text /
dimension / multileader styles, annotation symbols, sheet graphics and a full production
suite (scale, grids, areas, stamps, revisions, notes, hatch library, layer control,
QA, page setup and publishing) plus the 4.0 studio suite (layouts with scaled
viewports, section / elevation / match / break / cloud markers, dimension launcher,
parametric symbol library, door schedules, text find/replace, live fields, project
data files and timestamped backups) plus the 5.0 delivery suite (parametric walls
and stairs, linear takeoff, bill of materials, room finishes and drawing registers,
xref register, transmittal records, layer states, ByLayer standardisation, drawing
clean-up and project-driven drawing properties) plus the 6.0 site and services
suite (solar study diagrams, falls and drainage runs, parking and tiling setout,
reflected ceiling plans, level and keynote libraries, a printable standard report
and a stray-layer audit) plus the 7.0 coordination suite (bounding-box clash
checks between layer groups, parametric gable / hip / shed roof plans, balustrades
with spaced posts, a glazing schedule counted from the symbol library, zone plans
hatched by area band, block swap, tag renumbering, text-to-baseline alignment, a
full object information report and true-north orientation).

Version string inside the LISP: `*RMR-VERSION* = "7.0 COORDINATION SUITE"`.

## Package contents

| File | Purpose |
| --- | --- |
| `RooMNRooF_Master.lsp` | The complete AutoLISP application (generator + production suite). |
| `README.md` | This document. |
| `preview/RooMNRooF_PRO_Standard_Preview.dxf` | A1 preview sheet generated from the shipped palette data (open in AutoCAD or any DXF viewer). |
| `preview/RooMNRooF_PRO_Standard_Preview.png` | Rendered A1 preview sheet (dark presentation ground). |
| `preview/RooMNRooF_PRO_Plan_Detail.png` | Zoomed 1:50 sample apartment plan from the same sheet. |
| `preview/RooMNRooF_PRO_Studio_Suite.dxf` | A1 sheet showing the 4.0 studio suite: layouts, viewports, title block, markers, symbol library and door schedules. |
| `preview/RooMNRooF_PRO_Studio_Suite.png` | Rendered studio-suite sheet. |
| `preview/RooMNRooF_PRO_Delivery_Suite.dxf` | A1 sheet showing the 5.0 delivery suite: parametric walls and stair, takeoff, bill of materials, finishes, register, transmittal, xrefs and housekeeping. |
| `preview/RooMNRooF_PRO_Delivery_Suite.png` | Rendered delivery-suite sheet. |
| `preview/RooMNRooF_PRO_Site_Services_Suite.dxf` | A1 sheet showing the 6.0 site and services suite: solar study, drainage, parking, tiling setout, RCP, level schedule, keynote legend and report excerpt. |
| `preview/RooMNRooF_PRO_Site_Services_Suite.png` | Rendered site and services sheet. |
| `preview/RooMNRooF_PRO_Coordination_Suite.dxf` | A1 sheet showing the 7.0 coordination suite: clash check, roof plans, balustrade and glazing schedule, zone plan with the band legend, the swap / renumber / align fixes and the object information report. |
| `preview/RooMNRooF_PRO_Coordination_Suite.png` | Rendered coordination sheet. |
| `tools/rmr_lint.py` | Standalone static checker that validates the LISP structure before delivery. |
| `tools/make_preview_dxf.py` | Regenerates the preview DXF/PNGs directly from the LISP data tables (needs `ezdxf`, `matplotlib`). |
| `tools/check_preview_sheets.py` | Layout audit for the generated sheets: text outside the frame and copy that would overprint other copy. |

The binary `.DWT` template is intentionally **not** shipped: it can only be produced
inside AutoCAD by loading the LISP and running `RMR-SAVE-TEMPLATE`.

## Install and generate the master

1. Open a blank metric AutoCAD drawing.
2. `APPLOAD` → load `RooMNRooF_Master.lsp`.
3. Run `RMR-MASTER` (or `RMR-PRO-SETUP` for a first-time / refresh install).
4. Optional: run `RMR-SAVE-TEMPLATE` to write `RooMNRooF_PRO_Standard.dwt` next to the
   drawing (or into the AutoCAD template folder when writable).

`RMR-MASTER` is idempotent and preserves existing office styles. `RMR-PRO-SETUP`
additionally refreshes the RMR-owned text styles to the PRO font stack; set
`*RMR-FORCE-STYLE-REFRESH*` to `T` to force the same refresh from `RMR-MASTER`.

## Command reference (77 commands)

### Setup, palette and templates
| Command | What it does |
| --- | --- |
| `RMR-MASTER` | Grouped launcher: builds/updates the full standard and offers the production tools. |
| `RMR-PRO-SETUP` | Full PRO build: layers, true colours, linetypes, text styles, dim styles, MLeader style, symbol blocks, standards variables. |
| `RMR-SAVE-TEMPLATE` | Saves the current drawing as the reusable `.DWT` template. |
| `RMR-PALETTE` | Interactive palette editor: list groups, edit layer colour/linetype/lineweight/description, add layers, dump the palette. |
| `RMR-EXPORT-PALETTE` | Writes the live palette to a `;`-delimited CSV (8 fields per row). |
| `RMR-IMPORT-PALETTE` | Reads a palette CSV back in and rebuilds the standard from it. |
| `RMR-LAYGROUP` | Freeze/Thaw/Off/On/Lock/Unlock a whole layer group (protects the current layer). |
| `RMR-SETLAYER` | Quick set-current-layer by wildcard-filtered pick list. |

### Annotation and presentation
| Command | What it does |
| --- | --- |
| `RMR-ROOMTAG` | Scale-aware room tag (number, name, m² + ft²) on `RMR-A-ROOM`. |
| `RMR-KEYNOTE` | Gold chevron leader + numbered keynote bubble. |
| `RMR-MLEADER` | Branded multileader using the `RMR-MLEADER` style. |
| `RMR-DETAIL` | Detail callout bubble (mark + sheet reference). |
| `RMR-LEVEL` | Level datum marker with formatted ± level text. |
| `RMR-NORTH` | Inserts/rotates the `RMR-NORTH-ARROW` block. |
| `RMR-REVISION` | Revision cloud tag (triangle marker + rev letter). |
| `RMR-REVTABLE` | Revision history table with branded header row. |
| `RMR-STAMP` | Rotatable double-border issue stamp (rev, date, auto-fitted label). |
| `RMR-NOTES` | Numbered general notes as wrapped MTEXT paragraphs. |
| `RMR-LEGEND` | Colour / layer / linetype legend generator. |
| `RMR-SHEET` | A0–A4 sheet frame, border and branded title block. |
| `RMR-SCALEBAR` | Graphic scale bar for the active drawing scale. |
| `RMR-KEYPLAN` | Mini key plan box with north arrow and outline. |

### Studio suite (new in 4.0)
| Command | What it does |
| --- | --- |
| `RMR-LAYOUTS` | Creates a new layout: paper size (A0–A4), branded `RMR-TITLEBLOCK` with live attributes, and an optional scaled viewport. |
| `RMR-VPORT` | Adds a scaled, display-locked viewport to the active layout (falls back to `MVIEW` where ActiveX is unavailable). |
| `RMR-SECTION` | Section cut line with viewing-direction arrows and numbered sheet bubbles at both ends. |
| `RMR-ELEVATION` | Elevation marker with direction arrow, number and sheet reference. |
| `RMR-MATCHLINE` | Phantom match line to the adjoining sheet, with upright labels at both ends. |
| `RMR-BREAKLINE` | Break / cut line drawn as a bulged polyline. |
| `RMR-REVCLOUD` | Revision cloud: pick points, or pick two corners for a rectangular cloud. |
| `RMR-DIM` | Dimension launcher: pick a style (`RMR-DIM-PLAN/DETAIL/LARGE`) then linear, aligned, ordinate, radial, angular or continue. |
| `RMR-SYMBOLS` | Builds the parametric `RMR-SYM-*` library: doors (700/800/900/1000 single, 1500 double), window, WC, basin, shower, single/double bed, desk, chair, sofa, washer. |
| `RMR-DOORSCHED` | Door schedule table built from inserted `RMR-SYM-DOOR*` blocks and their `TAG` / `WIDTH` attributes, sorted by tag. |
| `RMR-FINDTEXT` | Find / replace across `TEXT`, `MTEXT` and `ATTRIB`, with `*` wildcards. |
| `RMR-FIELDS` | Inserts live fields (date, drawing name, layout, area, block name) or project values as static text. |
| `RMR-PROJECT` | Show / set / save / load project data (`*RMR-PROJECT*`), and fill every inserted title block from it. |
| `RMR-BACKUP` | Timestamped backup copy of the drawing into the drawing folder. |


### Delivery suite (new in 5.0)
| Command | What it does |
| --- | --- |
| `RMR-WALL` | Parametric double-line wall: pick a wall type (`*RMR-WALL-SPECS*`) then a path; corners are mitred so both faces stay exactly on thickness, with cap lines and a type label. |
| `RMR-STAIR` | Parametric straight stair: width, risers, going and direction of travel produce the outline, treads, walking line, direction arrow and an "UP 16R @ 280" label. |
| `RMR-LENGTH` | Linear takeoff across LINE / LWPOLYLINE / ARC / CIRCLE / ELLIPSE / SPLINE, with an optional in-drawing label and CSV export. |
| `RMR-BOM` | Bill of materials from block inserts, counted per block name **and** layer, sorted by quantity, drawn as a table and/or written to CSV. |
| `RMR-FINISHES` | Room finishes schedule (room, floor, skirting, wall, ceiling, notes) straight from the editable `*RMR-FINISH-SPECS*` table. |
| `RMR-SHEETREG` | Drawing register / sheet index from the editable `*RMR-SHEET-LIST*` table. |
| `RMR-XREFLIST` | Lists attached xrefs with resolved source paths and draws an xref register table. |
| `RMR-TRANSMITTAL` | Issue / transmittal record for the whole set: sheet, title, revision, issue date and a signature column, headed with the live project data. |
| `RMR-LAYERSTATE` | Save / restore / list / delete layer states in a plain `.rms` text file (`Name;Colour;Linetype;Lineweight;Frozen;Off;Locked`). Restore preserves xref-dependent flags and reports what it skipped. |
| `RMR-STANDARDIZE` | Forces colour, linetype and lineweight of a selection (or the whole drawing) to `BYLAYER`. |
| `RMR-CLEAN` | Three `-PURGE` passes plus an `AUDIT`, then optionally runs `RMR-STANDARDIZE`. |
| `RMR-DWGPROPS` | Writes title, subject, author, category, keywords and comments from `*RMR-PROJECT*` into the drawing properties. |


### Site and services (new in 6.0)
| Command | What it does |
| --- | --- |
| `RMR-SUNPATH` | Solar study diagram for a chosen latitude: horizon circle, altitude rings, summer / equinox / winter declination curves, hour marks, N-E-S-W and the three noon altitudes. |
| `RMR-FALL` | Fall arrow between two points with the gradient label and the drop calculated over the picked run (1:40 / 1:60 / 1:80 / 1:100 / 1:120). |
| `RMR-DRAIN` | Drainage run along a picked path: pipes, numbered manholes and invert levels that fall automatically at the chosen gradient. |
| `RMR-PARK` | Parametric parking row: bay width, depth, count, aisle and 90 / 60 / 45 degree bay angle, with numbered bays and a summary label. |
| `RMR-TILE` | Tiling setout grid with tile count and waste allowance; reports how many tiles to order. |
| `RMR-RCP` | Reflected ceiling plan: ceiling grid module plus light fittings at a chosen spacing, with a fitting count. |
| `RMR-LEVELSCHED` | Level schedule from the editable `*RMR-LEVEL-SPECS*` table. |
| `RMR-KEYLIB` | Keynote legend drawn straight from the editable `*RMR-KEYNOTES*` library. |
| `RMR-REPORT` | Writes a printable text report of the entire standard: project data, layers by group, text and dimension styles, hatch library, wall types, levels, keynotes, drawing register and notes. |
| `RMR-STRAY` | Audits the drawing for objects on layers that are not in `*RMR-LAYER-SPECS*` (ignoring xrefs, layer 0 and Defpoints) and can move them onto a standard layer. |


### Coordination suite (new in 7.0)
| Command | What it does |
| --- | --- |
| `RMR-CLASH` | Bounding-box clash check between two layer groups (MAIN / FURNITURE / STRUCTURAL / PLUMBING). Every box in one group is compared with every box in the other; overlaps are listed with the two layers and the overlap area in mm² and can be circled on `RMR-A-REVISION`. |
| `RMR-ROOF` | Parametric roof plan from two corners: GABLE / HIP / SHED, eaves overhang (600 mm default) and pitch (25° default). The ridge runs along the longer axis; the hip ridge is `long − short`, the gable ridge is the full length and a shed draws no ridge. Adds a slope arrow and a `TYPE \| PITCH n DEG \| n m EAVES` label. |
| `RMR-RAIL` | Balustrade along a picked polyline path: thickness (100 mm default) and post spacing (1100 mm default). Offsets the path to both faces and places post circles, skipping the duplicated post at every shared corner vertex. |
| `RMR-WINDOWSCHED` | Glazing schedule counted from the `RMR-SYM-WINDOW*` inserts in the drawing, grouped by block name and layer, sorted descending by quantity, drawn as a `NO. / TYPE / LAYER / QTY` table. |
| `RMR-ZONE` | Hatches each selected closed area on `RMR-M-AREA` with the colour and pattern of its band from `*RMR-ZONE-BANDS*`, prints the band counts and total m², and can draw the band legend with the total. |
| `RMR-BLKSWAP` | Replaces every insert of one block with another while keeping the layer, insertion point, rotation and scale. Attributed inserts are skipped and counted, because their attribute references cannot be rebuilt safely. |
| `RMR-RENUMBER` | Renumbers picked TEXT / MTEXT tags in selection order with an optional prefix, a start number and optional two-digit padding. |
| `RMR-TEXTALIGN` | Projects the insertion point of each selected single-line text onto a picked baseline and rotates the text to match the line (resets DXF 72 / 73 and sets 50 to the baseline angle). |
| `RMR-INFO` | Full report for one object: entity type, layer, colour (BYLAYER / BYBLOCK / index), true colour R-G-B, linetype, lineweight, block name, style, text content, plus length in mm and m and area in m² and sq ft. |
| `RMR-ORIENT` | Rotates every object in model space about a picked base point by a prompted angle so drawing north matches true north; answer `No` to only read the current angle. |


### Production suite
| Command | What it does |
| --- | --- |
| `RMR-SCALE` | Sets the drawing scale by keyword (1:20 … 1:200), model or layout annotation space; syncs `DIMSCALE`, `CELTSCALE`, `LTSCALE`, `MSLTSCALE`, `PSLTSCALE` and the scale label. |
| `RMR-GRID` | Structural grid lines with lettered/numbered bubbles (skips I and O, then AA, AB…). |
| `RMR-AREA` | Computes room areas (closed boundary pick) and builds the m²/ft² area schedule table. |
| `RMR-HATCHLIB` / `RMR-HATCH` | 12-material hatch library; hatch a closed area by material keyword. |
| `RMR-COUNT` | Block takeoff by name and layer, optional CSV export, console report. |
| `RMR-CHECK` | Drawing QA pass (`ssget "X"` audit of layers/linetypes/styles/text) with PASS/REVIEW verdict, optional `.txt` report. |
| `RMR-PAGESETUP` | Named page setup with brand plot device, plot style and paper size. |
| `RMR-PUBLISH` | Writes a `.dsd` sheet set for one-click PDF publish of the drawing. |

All annotation commands ask for the symbol scale once per session and honour
`*RMR-ANNO-SCALE*` / `*RMR-ANNO-SPACE*` (model vs layout annotation).

## Editing the palette (group-wise, future-proof)

All visual data lives in plain editable tables near the top of the LISP:

- `*RMR-LAYER-SPECS*` — `("LayerName" "Group" (R G B) "Linetype" Lineweight "Description")`
- `*RMR-TEXT-STYLES*` — `(name font width oblique description)`
- `*RMR-DIMSTYLE-SPECS*` — `(name textheight arrowsize description)`
- `*RMR-MLEADER-SPECS*` — multileader style definitions
- `*RMR-BRAND-*` — INK / TERRACOTTA / TEAL / GOLD / SAND / BLUE / SLATE RGB triples
- `*RMR-HATCH-SPECS*`, `*RMR-STAMP-SPECS*`, `*RMR-NOTES*`, `*RMR-PAPER-SPECS*`,
  `*RMR-SCALE-SPECS*`, `*RMR-GRID-LETTERS*`, plot/publish defaults
- `*RMR-PROJECT*` — dotted-pair project data (CLIENT, PROJECT, JOB, STAGE, TITLE,
  DWGNO, REV, DATE, DRAWN, CHECKED, SCALE, SIZE) used by the title block,
  fields and schedules; save/load it with `RMR-PROJECT`.
- `*RMR-CLOUD-ARC*` — revision cloud bulge factor (default `0.65`)
- `*RMR-WALL-SPECS*` — wall types: `(Key Thickness Layer Description)`
- `*RMR-FINISH-SPECS*` — room finishes: `(Room Floor Skirting Wall Ceiling Notes)`
- `*RMR-SHEET-LIST*` — drawing register / transmittal rows:
  `(SheetNumber Title Scale Revision Status)`
- `*RMR-LEVEL-SPECS*` — level schedule rows: `(Level Height_mm Description)`
- `*RMR-KEYNOTES*` — keynote library: `(Number Text)`
- `*RMR-SUN-CITIES*` — reference latitudes for `RMR-SUNPATH`: `(City Latitude)`
- `*RMR-ZONE-BANDS*` — zone bands for `RMR-ZONE`: `(Label MaxArea_m2 (R G B) Pattern)`,
  a teal ramp `UNDER 5 → 5 TO 15 → 15 TO 30 → 30 TO 60 → OVER 60` m², all `ANSI31`

Groups currently shipped: **Control, Main Theme, Furniture, Structural, Plumbing,
Annotation, Presentation**. Version 4.0 adds `RMR-A-MATCH` (match / break / cut
lines, phantom) and `RMR-PRES-VPORT` (viewport frames and labels) to those groups. Add a row (or a whole new group) and every generator,
legend, layer-group command and the preview tool pick it up automatically. For
non-LISP workflows use `RMR-EXPORT-PALETTE` / `RMR-IMPORT-PALETTE` (CSV round-trip).

Layer descriptions are stored the AutoCAD-native way: XDATA under
`AcAecLayerStandard` plus the COM `Description` property where ActiveX exists, so they
show up in the Layer Properties Manager.

## Production workflow cheat-sheet

```text
RMR-PRO-SETUP        ; once per office / template
RMR-LAYOUTS  A1      ; layout: paper + title block + scaled viewport
RMR-SHEET  A1        ; frame + title block (model-space sheet)
RMR-SCALE  1:50 LAYOUT
RMR-GRID             ; structural bubbles
RMR-HATCH            ; materials
RMR-ROOMTAG          ; room tags with areas
RMR-AREA             ; area schedule
RMR-WALL  RMR-STAIR        ; parametric walls and stairs
RMR-SECTION RMR-ELEVATION RMR-MATCHLINE RMR-BREAKLINE RMR-REVCLOUD
RMR-DIM                ; dimensions on the right style and layer
RMR-SYMBOLS RMR-DOORSCHED
RMR-KEYNOTE RMR-LEVEL RMR-DETAIL RMR-NORTH
RMR-NOTES  RMR-REVTABLE  RMR-STAMP
RMR-FINISHES  RMR-SHEETREG   ; finishes and drawing register
RMR-BOM  RMR-LENGTH          ; quantities
RMR-XREFLIST                 ; check attached references
RMR-FINDTEXT         ; global wording fixes
RMR-PROJECT FILLTITLE ; push project data into every title block
RMR-LAYERSTATE SAVE / RMR-STANDARDIZE  ; freeze a state, force BYLAYER
RMR-CLEAN  RMR-DWGPROPS      ; clean up and stamp the properties
RMR-STRAY  RMR-REPORT        ; audit layers, print the standard
RMR-CHECK            ; QA before issue
RMR-PAGESETUP  RMR-PUBLISH
RMR-SUNPATH  RMR-FALL  RMR-DRAIN   ; site studies
RMR-PARK  RMR-TILE  RMR-RCP        ; setout and services
RMR-LEVELSCHED  RMR-KEYLIB         ; schedules and legends
RMR-CLASH  RMR-ZONE                ; coordinate before issue
RMR-ROOF  RMR-RAIL                 ; roof plan and balustrade
RMR-WINDOWSCHED                    ; glazing quantities
RMR-BLKSWAP  RMR-RENUMBER  RMR-TEXTALIGN
RMR-INFO  RMR-ORIENT               ; interrogate and orientate
RMR-TRANSMITTAL      ; issue record for the set
RMR-BACKUP           ; timestamped safety copy
RMR-SAVE-TEMPLATE    ; freeze as .DWT
```

## Preview sheet and QA tooling

`tools/make_preview_dxf.py` parses the LISP data tables (it never hard-codes palette
values) and rebuilds five A1 sheets: the standard sheet (below) and
`RooMNRooF_PRO_Studio_Suite.dxf`, which previews the 4.0 studio suite — layout and
viewport setup, the branded `RMR-TITLEBLOCK`, section / elevation / match / break /
cloud markers, the `RMR-SYM-*` symbol gallery, a door schedule and the project-data
panel — and `RooMNRooF_PRO_Delivery_Suite.dxf`, which previews the 5.0 delivery
suite: a mitred parametric wall plan, a 16-riser stair, the takeoff readout and
bill of materials, the finishes schedule, drawing register, transmittal record,
xref register and the housekeeping panel — and
`RooMNRooF_PRO_Site_Services_Suite.dxf`, which previews the 6.0 site and services
suite: the solar study diagram, a drainage run with invert levels, parking bays,
a tiling setout, a reflected ceiling plan, the level schedule, the keynote legend
and a report excerpt, and `RooMNRooF_PRO_Coordination_Suite.dxf`, which previews the
7.0 coordination suite: a clash check on two overlapping service runs, hip and gable
roof plans with the ridge lengths, a balustrade with spaced posts and the glazing
schedule, the zone plan with its band legend, the block swap / renumber / text-align
fixes and the object information report with the true-north rotation. The standard
sheet contains: sample 1:50 apartment plan with walls,
doors, glass, columns, furniture, plumbing, grid bubbles, room tags, dimensions,
keynotes, level datum, section marker, north arrow, scale bar, area schedule,
revision table, layer palette legend, text-style samples, symbol gallery, the
12-material hatch strip, general notes and the command panel. Regenerate with:

```bash
python -m venv .venv-rmr && .venv-rmr/bin/pip install ezdxf matplotlib
./.venv-rmr/bin/python autocad/tools/make_preview_dxf.py
./.venv-rmr/bin/python autocad/tools/check_preview_sheets.py   # layout audit
```

`tools/check_preview_sheets.py` reads the generated DXFs back and reports copy that
runs outside the sheet frame and text boxes that would print on top of each other.
Current state across the five sheets: **0 problems** (1,179 text entities checked).

`tools/rmr_lint.py` statically checks the LISP before every delivery (string
termination, parenthesis balance, defun argument/local hygiene, duplicate defuns,
undeclared `setq`, unknown function calls, quoted-symbol references and unset global
variables). Current state: **PASS**, 0 findings (255,703 bytes / 6,382 lines, 211 defuns,
77 commands).

```bash
python3 autocad/tools/rmr_lint.py autocad/RooMNRooF_Master.lsp
```

## Notes and limitations

- `RMR-CLASH` compares bounding boxes, not solids: two objects whose boxes overlap
  but whose geometry does not will still be listed. Treat the output as a review
  list to walk through, not as a clash engine result.
- `RMR-ROOF` takes the longer picked edge as the ridge direction, so the same two
  corners give a hip ridge of `long − short` and a gable ridge of the full length.
- `RMR-RAIL` walks each polyline segment separately and skips the first post of every
  segment after the first, so a shared corner vertex gets one post, not two.
- `RMR-BLKSWAP` rebuilds inserts with `entmake`; attributed inserts (DXF 66 = 1) are
  skipped and reported, so check the skip count before trusting a furniture swap.
- `RMR-SUNPATH` uses the standard solar position formulae (declination,
  hour angle, altitude and azimuth); noon altitude equals `90 - |latitude -
  declination|`, and southern latitudes put the noon sun in the north.
- `RMR-TILE` and `RMR-RCP` cap setout lines at 80 per direction so very large
  rooms cannot flood the drawing with geometry.
- `RMR-WALL` mitres corners by bisecting the offset; extremely sharp corners are
  clamped to four times the offset so geometry can never run away.
- `RMR-LAYERSTATE` uses its own `.rms` text format instead of the `-LAYERSTATE`
  command line, so it behaves identically on every AutoCAD build.
- `RMR-LAYOUTS` / `RMR-VPORT` create viewports through ActiveX and fall back to the
  `MVIEW` command where `vla-addpviewport` is unavailable (some 64-bit builds).
- `RMR-BACKUP` leaves you in the newly saved backup drawing, matching AutoCAD's
  `SAVEAS` behaviour.
- Requires full AutoCAD 2018+ (ActiveX paths degrade gracefully on AutoCAD LT /
  restricted environments; hatch, COM styling and plotting are wrapped in
  `vl-catch-all-apply` and report failures instead of crashing).
- Plot device / plot style names (`*RMR-PLOT-DEVICE*`, `*RMR-PLOT-STYLE*`) must exist on
  the machine that plots; defaults fall back to `DWG To PDF.pc3` and `monochrome.ctb`.
- The `.DWT` is produced in AutoCAD via `RMR-SAVE-TEMPLATE`; this package ships the
  generator, documentation and previews only.
