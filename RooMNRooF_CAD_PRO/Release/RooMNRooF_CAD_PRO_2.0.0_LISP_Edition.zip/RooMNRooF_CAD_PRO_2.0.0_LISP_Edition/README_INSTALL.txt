RooMNRooF CAD PRO ULTIMATE 2.0.0 - LISP Edition
=================================================

INSTALL
  1. Close AutoCAD.
  2. Extract this zip, double-click Install.bat.
  3. Start AutoCAD (2021 or newer, 64-bit). Choose "Always Load" if AutoCAD asks about RNR_Load.lsp
     (or add %APPDATA%\Autodesk\ApplicationPlugins to Options > Files > Trusted Locations).
  4. Type RNRL-SELFTEST (expect 0 FAIL), then RNRL-HELP.
     Full checklist: Contents\Documentation\10_Install_And_Verify.md

  Manual alternative: APPLOAD  ->  RooMNRooF.bundle\Contents\AutoLISP\RNR_Load.lsp

UNINSTALL
  Run Uninstall.bat (removes only the bundle folder).

COMMANDS (35)
  Layers/standards: RNRL-LAYERS RNRL-ARCH RNRL-STRUCT RNRL-CIVIL RNRL-ANNO RNRL-RCC RNRL-LA RNRL-THAW
                    RNRL-COLORS RNRL-COLORAPPLY RNRL-BYLAYER RNRL-UNITS RNRL-STYLES
  Drafting:         RNRL-GRID RNRL-WALL RNRL-DOOR RNRL-WINDOW RNRL-ROOM RNRL-COLUMN RNRL-BEAM RNRL-FOOTING
  Rebar/hatch:      RNRL-REBAR RNRL-BARWT RNRL-HATCH
  Blocks/annotation:RNRL-INSERT RNRL-BLOCKLIST RNRL-TAG RNRL-LEVEL RNRL-NORTH
  QA/plot:          RNRL-QA RNRPLOT-BW RNRPLOT-COLOR RNRPLOT-GRAY   Help: RNRL-HELP  Check: RNRL-SELFTEST

INCLUDED
  Contents\AutoLISP   15 LISP modules
  Contents\Hatch      custom PAT hatch patterns (on the support path after install)
  Contents\Standards  JSON standards + RooMNRooF.lin
  Contents\Samples    12 sample DXF drawings (3-storey residence)
  Contents\Documentation

NOT INCLUDED IN THIS EDITION
  The C# plugin (RNR* commands, WPF palette, BBS/BOQ Excel export, DWT generator, MSI). It must be
  compiled on Windows: see Documentation\06_Build_And_Release.md in the source repository.

STATUS / DISCLAIMER
  The LISP code passed static checks (brackets, reserved symbols, duplicates) but has NOT yet been
  run inside AutoCAD by the author. Please report any command-line errors.
  This is a drafting tool. It does not perform structural design or verify BNBC 2020 / ACI 318-19 /
  ASCE 7 compliance. Sample member sizes/reinforcement are placeholders. BBS/BOQ are estimates.
