@echo off
REM Removes only the RooMNRooF bundle folder. Your drawings are not touched.
set DST=%APPDATA%\Autodesk\ApplicationPlugins\RooMNRooF.bundle
if not exist "%DST%" ( echo RooMNRooF.bundle is not installed for this user. & pause & exit /b 0 )
choice /M "Remove %DST%"
if errorlevel 2 exit /b 1
rmdir /S /Q "%DST%" && echo Removed.
pause
